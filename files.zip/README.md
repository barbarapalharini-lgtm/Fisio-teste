# Sistema de Avaliação de Risco de Lesões — Backend (cálculo de risco)

Esta é a primeira etapa do sistema: o "cérebro" que calcula assimetrias,
classifica riscos e sugere condutas fisioterapêuticas, replicando a lógica
que a fisioterapeuta já usa na planilha e no laudo da clínica funcional.e.

## Estrutura

```
app/
  calculations/
    reference_values.py   # valores de referência/normalidade de cada teste
    schemas.py             # modelos de entrada/saída (Pydantic)
    risk_calculator.py      # lógica de cálculo e classificação de risco
  tests/
    test_risk_calculator.py # testes validados com dados reais da Regiane
```

## Como rodar os testes

```bash
pip install -r requirements.txt
pytest app/tests/ -v
```

(Testes já foram validados manualmente neste ambiente e batem com os
valores do laudo em PDF fornecido — ex.: assimetria de quadríceps 42,05%,
razão QD/IT de 24,40%/15,26%, Single Hop ~12,9% etc.)

## O que já está pronto

- Cálculo de assimetria entre lados (mesma fórmula da planilha:
  `100 - (menor/maior × 100)`)
- Classificação de risco (normal / moderado / alto) para:
  - Força de quadríceps e isquiotibiais + Razão QD/IT
  - Resistência do CORE (extensores de tronco, prancha lateral)
  - Mobilidade de quadril e tornozelo (Lunge test)
  - ADM passiva e ativa de rotação de ombro (GIRD)
  - Y Balance Test
  - Força simétrica genérica (dinamômetro isométrico — qualquer grupo
    muscular: glúteo médio, glúteo máximo, adutores etc.)
  - Single Hop Test
  - Força de preensão palmar
  - Flexão passiva / adução horizontal de ombro
  - Escala de carga e recuperação
- Texto de conduta fisioterapêutica sugerido automaticamente, no mesmo
  estilo do laudo, indicando o lado/grupo muscular a trabalhar.

## ⚠️ Pendência importante: índice de risco geral (o "medidor" do laudo)

O laudo da funcional.e mostra um índice final único, ex. **"50,9 ua — risco
moderado"**, que resume todos os testes num só medidor (vermelho/amarelo/
verde). **Não encontrei a fórmula desse índice na planilha** — ele parece
ser calculado à parte (talvez manualmente ou em outra ferramenta).

Implementei uma fórmula **provisória** (`_calcular_indice_risco_geral_provisorio`
em `risk_calculator.py`): cada teste NORMAL = 0 pontos, MODERADO = 50,
ALTO = 100, e o índice final é a média simples. Isso é só um placeholder —
precisa ser validado (ou substituído) com a fisioterapeuta, porque ela pode
querer dar pesos diferentes a testes diferentes (ex. testes de joelho podem
pesar mais que testes de ombro, dependendo da queixa do paciente).

## Próximos passos sugeridos

1. Validar com a fisioterapeuta a fórmula do índice de risco geral.
2. Modelo de dados / banco (paciente, histórico de avaliações ao longo do
   tempo).
3. API (FastAPI) expondo esses cálculos.
4. Geração automática do laudo em PDF (layout da funcional.e).
5. Frontend (formulário de entrada de dados, replicando a aba "Perfil de
   Risco" da planilha).
